$(function(){
    var ChxGithubPreUtility = window.ChxGithubPreUtility = window.ChxGithubPreUtility || {};
    ChxGithubPreUtility.Controller.run();
});
