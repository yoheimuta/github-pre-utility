$(function(){
    var ChxGithubPreUtility = window.ChxGithubPreUtility = window.ChxGithubPreUtility || {};
    ChxGithubPreUtility.KeydownEvent.startWrap(82);
    ChxGithubPreUtility.KeydownEvent.startCollapse(84, 80);
});
